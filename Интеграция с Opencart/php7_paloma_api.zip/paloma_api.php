<?php

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

include('config.php');
//-----Необходимо установить токен
$OpenCart_token = '';

//----Проверка токена
if (!isset($_REQUEST['token'])) {
    echo 'Ошибка, нет данных для обработки';
    die;
} else {
    $mas = json_decode($_POST['json'], true);
    $token = $_REQUEST['token'];
    $action = $_REQUEST['action'];
}

if ($token <> $OpenCart_token) {
    echo 'Ошибка, Токен не совпадает';
    die;
}
//echo 'Пятое значение массива: '. print_r($mas[5]).'<br>';
// die;
//Подключение к бд
$db = mysqli_connect(DB_HOSTNAME, DB_USERNAME, DB_PASSWORD, DB_DATABASE);
mysqli_query($db, "SET NAMES 'utf8'");

if ($db) {
    //  echo 'Соединение установленно успешно<br>';
} else {
    echo 'Ошибка соединение не установленно<br>';
    die;
}
if ($action == 'orders') {
    //echo 'Вставка заказов<br>';
    echo GetOrders($db, $OpenCart_token);
    die;
} elseif ($action != 'items') {
    echo 'Неизвестное событие<br>';
    die;
}

function GetOrders($db1, $OpenCart_token1) {
    $from = $_REQUEST['dtfrom'];
    if (!isset($_REQUEST['dtfrom']) || empty($_REQUEST['dtfrom'])) {
        $from = "";
    } else {
        $from = " AND DATE(o.date_modified) >= DATE(DATE_FORMAT('" . $_REQUEST['dtfrom'] . "','%Y-%m-%d %H:%i:%S')) ";
    }
    // Проставляем статусы заказов
    // Поиск удаленных заказов
    $sql = "update paloma_orders po 
             set po.action='delete', 
               po.import_date=now() 
             where po.order_id not in 
              (select oo.order_id from oc_order oo)";
    mysqli_query($db1, $sql);
    //Поиск измененных заказов
    $sql = "update paloma_orders po 
             set po.action='update', 
               po.import_date=now() 
             where po.order_id in 
              (select oo.order_id 
              from oc_order oo 
              where oo.date_modified>=po.import_date)
             and po.action<>'delete' ";
    mysqli_query($db1, $sql);
    //Вставка новых заказов
    $sql = "insert paloma_orders (order_id,import_date,action)
             (select order_id,now(),'insert'
             from oc_order oo
             where oo.order_id not in (select po.order_id from paloma_orders po))";
    mysqli_query($db1, $sql);
    //Получение списка заказов
    $sql = "SELECT 
             o.order_id
             ,o.date_modified
             ,o.date_added
             ,o.invoice_prefix
             ,o.shipping_address_1
             ,o.total
             ,o.shipping_firstname
             ,o.shipping_lastname
             ,o.email
             ,o.telephone
             ,op.name
             ,op.model
             ,op.quantity
             ,op.price
             ,op.total as `summ`
             ,pa.id_paloma
             ,po.action
             FROM 	oc_order o
             JOIN 	oc_order_product op on op.order_id = o.order_id
             JOIN 	paloma_api pa on pa.id_opencard = op.product_id
             JOIN  paloma_orders po on po.order_id = o.order_id 
             WHERE	o.order_status_id = 1 and o.date_modified>=(select `value` from paloma_config where `key`='last_orders_export') and pa.isgroup = 0 
             ORDER BY 1";
    $table = mysqli_query($db1, $sql);
    // $rez = mysqli_fetch_array($table);
    if (!$table) {
        echo 'Заказы не найдены<br>';
        die;
    } else {
        $sql = "update paloma_config set `value`=now() where `key`='last_orders_export'";
        mysqli_query($db1, $sql);
        //Передаем заказы на сервер paloma365
        $orders = array();
        while ($row = mysqli_fetch_array($table)) {
            $orders[] = $row;
        }
        return json_encode($orders);
    }
}

//Проверка существования таблицы paloma_orders и ее создание
$table_create = mysqli_query($db, "SELECT * FROM paloma_orders");
if ($table_create) {
    //Таблица paloma_api существует
    $table_orders = mysqli_fetch_array($table_create);
} else {
    $sql = "CREATE TABLE `paloma_orders` (
            `id`  int NOT NULL AUTO_INCREMENT ,
            `order_id`  int NOT NULL ,
            `import_date`  datetime NOT NULL ,
            `action`  varchar(10) NOT NULL ,
            PRIMARY KEY (`id`)
            )";
    if (mysqli_query($db, $sql)) {
        echo 'Создана таблица paloma_orders<br>';
    } else {
        echo 'Ошибка таблица paloma_orders не создана<br>';
        die;
    }
}

//Проверка существования таблицы paloma_api и ее создание
$table_create = mysqli_query($db, "SELECT * FROM paloma_api");
if ($table_create) {
    //Таблица paloma_api существует
    $table_paloma = mysqli_fetch_array($table_create);
} else {
    $sql = "CREATE TABLE `paloma_api` (`id` INT NOT NULL AUTO_INCREMENT,`id_paloma` INT NOT NULL , `id_opencard` INT NOT NULL, `isgroup` INT NOT NULL, `parentid` INT NOT NULL, PRIMARY KEY (  `id` ))";
    if (mysqli_query($db, $sql)) {
        echo 'Создана таблица paloma_api<br>';
    } else {
        echo 'Ошибка таблица paloma_api не создана<br>';
        die;
    }
}

//Проверка существования таблицы paloma_config_api и проверка токена
$table_create = mysqli_query($db, "SELECT * FROM paloma_config WHERE `key`='token'");
if ($table_create) {
    //Таблица paloma_api_config существует
    $table_paloma_config = mysqli_fetch_array($table_create);
    if ($table_paloma_config['value'] != $token) {
        echo 'Ошибка, не верный токен';
        //print_r($token);
        die;
    }
} else {
    $sql = "CREATE TABLE `paloma_config` (`id` INT NOT NULL AUTO_INCREMENT,`key` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, `value` VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, PRIMARY KEY (`id`))";
    if (mysqli_query($db, $sql)) {
        echo 'Создана таблица paloma_config<br>';
        mysqli_query($db, "INSERT INTO paloma_config (`key`,`value`) VALUES ('last_orders_export',now())");
        $r = mysqli_query($db, "INSERT INTO paloma_config (`key`,`value`) VALUES ('token','$token')");
    } else {
        echo 'Ошибка таблица paloma_config не создана<br>';
        die;
    }
}

//Функция добавление нового товара
function add_product($id_paloma, $name, $parentid, $price, $db, $img, $qty) {
    if ($img != '') {
        $fn = explode("/", $img);
        $filename = $fn[count($fn) - 1];
        $imag = 'catalog/' . $filename;
        $local = 'image/' . $imag;
        file_put_contents($local, file_get_contents($img));
    } else {
        $imag = "";
    }

    $d = Date('Y-m-d');
//Добавление в таблицу oc_product
    $r = mysqli_query($db, "INSERT INTO oc_product (model,price,date_added,status,image,quantity) VALUES ('$name','$price','$d','1','$imag','$qty')");
    $idd = mysqli_insert_id($db);

    if (!$r) {
        echo 'error oc_product<br>';
    }

//Добавление в таблицу paloma_api    
    $r = mysqli_query($db, "INSERT INTO paloma_api (id_paloma,id_opencard,isgroup,parentid) VALUES ('$id_paloma','$idd','0','$parentid')");

    if (!$r) {
        echo 'error paloma_api<br>';
    }


//Добавление в таблицу oc_product_to_store
    $r = mysqli_query($db, "INSERT INTO oc_product_to_store (product_id,store_id) VALUES ('$idd','0')");

    if (!$r) {
        echo 'error oc_product_to_store<br>';
    }

//Добавление в таблицу oc_product_to_layout  
    $r = mysqli_query($db, "INSERT INTO oc_product_to_layout (product_id,store_id,layout_id) VALUES ('$idd','0','0')");

    if (!$r) {
        echo 'error oc_product_to_layout<br>';
    }

//Добавление в таблицу oc_product_description
    //$meta_title = 'Мета описание';
    //$description = 'Описание';
    $meta_title = $name;
    $description = $name;
    $r = mysqli_query($db, "INSERT INTO oc_product_description (product_id,language_id,name,description,meta_title) VALUES ('$idd','1','$name','$description','$meta_title')");
    if (!$r) {
        echo 'error oc_product_description<br>';
    }

//Добавление в таблицу oc_product_to_category
    $result = mysqli_query($db, "SELECT * FROM paloma_api WHERE id_paloma='$parentid'");
    $categ = mysqli_fetch_array($result);

    $cat = $categ['id_opencard'];

    $r = mysqli_query($db, "INSERT INTO oc_product_to_category (product_id,category_id) VALUES ('$idd','$cat')");
    if (!$r) {
        echo 'error oc_product_to_category<br>';
    }
    return 'Создан товар ' . $name . '<br>';
}

//Функция обновления товара
function update_product($id_paloma, $name, $parentid, $price, $db, $img, $qty) {
    if ($img != '') {
        $fn = explode("/", $img);
        $filename = $fn[count($fn) - 1];

        $imag = 'catalog/' . $filename;

        $local = 'image/' . $imag;
        file_put_contents($local, file_get_contents($img));
    } else {
        $imag = "";
    }

    $d = Date('Y-m-d');

    mysqli_query($db, "UPDATE paloma_api SET parentid='$parentid' WHERE id_paloma='$id_paloma'");

    //Новая категория товара
    $result = mysqli_query($db, "SELECT * FROM paloma_api WHERE id_paloma='$parentid'");
    $categ_paloma = mysqli_fetch_array($result);
    $new_categ_opencard = $categ_paloma['id_opencard'];

    //ID продукта в opencard
    $result = mysqli_query($db, "SELECT * FROM paloma_api WHERE id_paloma='$id_paloma'");
    $categ_paloma = mysqli_fetch_array($result);
    $id_product_opencard = $categ_paloma['id_opencard'];

    //Обновление категорий в таблице oc_product_to_category
    mysqli_query($db, "UPDATE oc_product_to_category SET category_id='$new_categ_opencard' WHERE product_id='$id_product_opencard'");

    //Обновление в таблице oc_product
    mysqli_query($db, "UPDATE oc_product SET model='$name', price='$price', date_modified='$d', image='$imag', quantity='$qty' WHERE product_id='$id_product_opencard'");

    //Обновление в таблице oc_product_description
    mysqli_query($db, "UPDATE oc_product_description SET name='$name', description='$name', meta_title='$name' WHERE product_id='$id_product_opencard'");

    return 'Обновлен товар ' . $name . '<br>';
}

//Функция добавление новой категорий
function add_category($id_paloma, $name, $parentid, $db) {

    $parent_opencard = 0;
    if ($parentid != 0) {
        $result = mysqli_query($db, "SELECT * FROM paloma_api WHERE id_paloma='$parentid'");
        $categ = mysqli_fetch_array($result);
        $parent_opencard = $categ['id_opencard'];
    }

    $d = Date('Y-m-d');
    mysqli_query($db, "INSERT INTO oc_category (parent_id,status,date_added,`column`,top) VALUES ('$parent_opencard','1','$d','1','1')");
    $id_categ_opencard = mysqli_insert_id($db);

    mysqli_query($db, "INSERT INTO paloma_api (id_paloma,id_opencard,isgroup,parentid) VALUES ('$id_paloma','$id_categ_opencard','1','$parentid')");

    mysqli_query($db, "INSERT INTO oc_category_to_store (category_id) VALUES ('$id_categ_opencard')");

    mysqli_query($db, "INSERT INTO oc_category_path (category_id,path_id) VALUES ('$id_categ_opencard','$id_categ_opencard')");
    if ($parent_opencard != 0) {
        mysqli_query($db, "INSERT INTO oc_category_path (category_id,path_id) VALUES ('$id_categ_opencard','$parent_opencard')");
    }

    mysqli_query($db, "INSERT INTO oc_category_to_layout (category_id) VALUES ('$id_categ_opencard')");

    mysqli_query($db, "INSERT INTO oc_category_description (category_id,language_id,name,meta_title,meta_description) VALUES ('$id_categ_opencard','1','$name','$name','$name')");
    return 'Создана категория ' . $name . '<br>';
}

//Функция обновления категорий
function update_category($id_paloma, $name, $parentid, $db) {
    $d = Date('Y-m-d');

    mysqli_query($db, "UPDATE paloma_api SET parentid='$parentid' WHERE id_paloma='$id_paloma'");

    $result = mysqli_query($db, "SELECT * FROM paloma_api WHERE id_paloma='$parentid'");
    $categ_paloma = mysqli_fetch_array($result);
    if (isset($categ_paloma['id_opencard'])) {
        $new_categ_opencard = $categ_paloma['id_opencard'];

        $result = mysqli_query($db, "SELECT * FROM paloma_api WHERE id_paloma='$id_paloma'");
        $categ_paloma = mysqli_fetch_array($result);

        $id_categ_opencard = $categ_paloma['id_opencard'];

        //Обновление таблицы oc_category
        mysqli_query($db, "UPDATE oc_category SET parent_id='$new_categ_opencard',date_modified='$d' WHERE category_id='$id_categ_opencard'");
        //Обновление таблицы oc_category_description
        mysqli_query($db, "UPDATE oc_category_description SET name='$name', meta_title='$name', meta_keyword='$name' WHERE category_id='$id_categ_opencard'");
    }
    return 'Обновлена категория ' . $name . '<br>';
}

//Очистка таблицы paloma_api от удаленных категорий
$res_categ = mysqli_query($db, "SELECT GROUP_CONCAT(id_opencard) as mascat_opencard FROM paloma_api WHERE isgroup='1'");
$gr_cat = mysqli_fetch_array($res_categ);

$mas_opencard_categ = explode(",", $gr_cat['mascat_opencard']);

$res_categ = mysqli_query($db, "SELECT GROUP_CONCAT(category_id) as opencard FROM oc_category");
$gr_cat = mysqli_fetch_array($res_categ);

$cat_opencard = explode(",", $gr_cat['opencard']);

for ($i = 0; $i <= count($mas_opencard_categ) - 1; $i++) {
    if (!in_array($mas_opencard_categ[$i], $cat_opencard)) {
        mysqli_query($db, "DELETE FROM paloma_api WHERE id_opencard='$mas_opencard_categ[$i]'");
    }
}

//Синхронизация категорий
$mas_paloma_categ = array();
$res_categ = mysqli_query($db, "SELECT id_paloma FROM paloma_api WHERE isgroup='1'");
while ($row = mysqli_fetch_array($res_categ)) {
    $mas_paloma_categ[] = $row['id_paloma'];
}
for ($i = 0; $i <= count($mas) - 1; $i++) {
    $isgroup = $mas[$i]['isgroup'];
    if ($isgroup != 0) {
        //echo "<br>";
        $id_paloma = $mas[$i]['id'];
        //echo $id_paloma."<br>";
        $parentid = $mas[$i]['parentid'];
        $name = $mas[$i]['name'];
        if (in_array($id_paloma, $mas_paloma_categ)) {
            //Обновление категорий
            echo update_category($id_paloma, $name, $parentid, $db);
        } else {
            //Добавление новой категорий
            echo add_category($id_paloma, $name, $parentid, $db);
        }
    }
}

//Очистка таблицы paloma_api от удаленных товаров
$res_categ = mysqli_query($db, "SELECT GROUP_CONCAT(id_opencard) as mascat_opencard FROM paloma_api WHERE isgroup='0'");
$gr_cat = mysqli_fetch_array($res_categ);

$mas_opencard_product = explode(",", $gr_cat['mascat_opencard']);

$res_categ = mysqli_query($db, "SELECT GROUP_CONCAT(product_id) as opencard FROM oc_product");
$gr_cat = mysqli_fetch_array($res_categ);

$cat_opencard = explode(",", $gr_cat['opencard']);

for ($i = 0; $i <= count($mas_opencard_product) - 1; $i++) {
    if (!in_array($mas_opencard_product[$i], $cat_opencard)) {
        mysqli_query($db, "DELETE FROM paloma_api WHERE id_opencard='$mas_opencard_product[$i]'");
    }
}


//Синхронизация товаров
$mas_paloma_product = array();
$res = mysqli_query($db, "SELECT id_paloma as product FROM paloma_api WHERE isgroup='0'");
while ($row = mysqli_fetch_array($res)) {
    $mas_paloma_product[] = $row['product'];
}
for ($i = 0; $i <= count($mas) - 1; $i++) {
    $isgroup = $mas[$i]['isgroup'];
    if ($isgroup == 0) {
        $name = $mas[$i]['name'];
        $id_paloma = $mas[$i]['id'];
        $d = Date('Y-m-d');

        $parentid = $mas[$i]['parentid'];
        $price = $mas[$i]['price'];
        $img = $mas[$i]['img'];
        $qty = $mas[$i]['remains'];
        if (in_array($id_paloma, $mas_paloma_product)) {
            echo update_product($id_paloma, $name, $parentid, $price, $db, $img, $qty);
        } else {
            echo add_product($id_paloma, $name, $parentid, $price, $db, $img, $qty);
        }
    }
}
?>
