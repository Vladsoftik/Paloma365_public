<?php
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
include('config.php');

set_time_limit(0);
class PalomaApi
{
    private $sync = [];
    private $syncFull = [];
    private $OpenCart_token = 'a1234567654321a';
    private $request = null;
    private $dataJson;
    private $action;
    private $token;
    private $log = [];

    private $db;

    public function __construct($REQUEST)
    {
        $this->request = $REQUEST;
        $this->connect();
        $this->checkToken();
        $this->init();

        $this->loadSyncDataOld();
    }

    public function getLog()
    {
        return $this->log;
    }
    private function init()
    {

        $sql = "CREATE TABLE IF NOT EXISTS `paloma_orders` (`id`  int NOT NULL AUTO_INCREMENT ,
            `order_id`  int NOT NULL , `import_date`  datetime NOT NULL ,
            `action`  varchar(10) NOT NULL , PRIMARY KEY (`id`))";
        if ($this->query($sql) === false) {
            throw new Exception('Ошибка таблица paloma_orders не создана');
        }

        $sql = "CREATE TABLE IF NOT EXISTS `paloma_api` (`id` INT NOT NULL AUTO_INCREMENT,
                    `id_paloma` INT NOT NULL , `id_opencard` INT NOT NULL, 
                    `isgroup` INT NOT NULL, `parentid` 
                      INT NOT NULL, PRIMARY KEY (  `id` ))";
        if ($this->query($sql) === false) {
            throw new Exception('Ошибка таблица paloma_api не создана');
        }

        $sql = "CREATE TABLE IF NOT EXISTS `paloma_config` (`id` INT NOT NULL AUTO_INCREMENT,`key` VARCHAR(255) 
                    CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, `value` 
                    VARCHAR(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL, 
                    PRIMARY KEY (`id`))";
        if ($this->query($sql) === false) {
            throw new Exception('Ошибка таблица paloma_config не создана');
        } else {
            $this->query("INSERT INTO paloma_config (`key`,`value`) VALUES ('last_orders_export',now())");
            $this->query("INSERT INTO paloma_config (`key`,`value`) VALUES ('token','$this->token')");
        }

    }

    private function loadSyncDataOld()
    {
        $this->sync = $this->getIdPaloma();
        $this->syncFull = $this->getIdPalomafullData();
    }

    private function checkToken()
    { // проверка и установка входных данных  и проверка токена
        if ($this->request['token'] <> $this->OpenCart_token) {
            //$table_create = mysqli_query($db, "SELECT * FROM paloma_config WHERE `key`='token'");
            // когда сделают возможность вводить днанные пользователь
            throw new Exception('Ошибка, Токен не совпадает');
        }
        if (!isset($this->request['token'])) {
            throw new Exception('Ошибка, нет данных для обработки');
        } else {
            $this->dataJson = json_decode($_POST['json'], true);
            $this->token = $this->request['token'];
            $this->action = $this->request['action'];
        }
    }
    private function connect($DB_HOSTNAME = false, $DB_USERNAME = false, $DB_PASSWORD = false, $DB_DATABASE = false)
    {
        $DB_HOSTNAME = ($DB_HOSTNAME) ? $DB_HOSTNAME : DB_HOSTNAME;
        $DB_USERNAME = ($DB_USERNAME) ? $DB_USERNAME : DB_USERNAME;
        $DB_PASSWORD = ($DB_PASSWORD) ? $DB_PASSWORD : DB_PASSWORD;
        $DB_DATABASE = ($DB_DATABASE) ? $DB_DATABASE : DB_DATABASE;
        $this->db = new mysqli($DB_HOSTNAME, $DB_USERNAME, $DB_PASSWORD, $DB_DATABASE);

        $this
            ->db
            ->query("SET NAMES 'utf8'");
        if (
            $this
                ->db
                ->connect_errno
        ) {
            throw new Exception('Ошибка соединение не установленно');
        }

    }
    private function query($sql, $transaction = false)
    {
        $result = $this
            ->db
            ->query($sql);
        if ($result === false) {
            $this->log[] = $sql;
            return $this
                ->db->connect_error;
        }

        return $result;
    }
    private function queryRow($sql)
    {

        $return = [];
        $row = $this->query($sql);
        if ($row === false) {
            return false;
        }
        if ($row->num_rows > 0) {
            while ($current_row = $row->fetch_assoc()) {
                $return[] = $current_row;
            }
        }
        $row->free();
        return $return;
    }
    //выполнения событий
    public function Action()
    {
        $result = null;
        switch ($this->action) {
            case 'orders':
                $result = $this->GetOrders();
                break;
            case 'items':
                $this->removeEmptyItemSyncTable();
                sleep(2);
                $this->syncProdCategory();
                break;
            case 'insert':
                break;
            case 'update':
                break;
            case 'delete':
                break;
            default:
                $result = "Событие не найдено";
                break;
        }
        $this
            ->db
            ->close();
        echo $result;
    }

    private function getlistOrder()
    {
        $sql = "SELECT o.order_id,o.date_modified,o.date_added
             ,o.invoice_prefix,o.shipping_address_1,o.total
             ,o.shipping_firstname,o.shipping_lastname
             ,o.email,o.telephone,op.name,op.model,op.quantity
             ,op.price,op.total as `summ`,pa.id_paloma,po.action
             FROM 	oc_order o
             JOIN 	oc_order_product op on op.order_id = o.order_id
             JOIN 	paloma_api pa on pa.id_opencard = op.product_id
             JOIN  paloma_orders po on po.order_id = o.order_id 
             WHERE	o.order_status_id = 1 and o.date_modified>=(select `value` from paloma_config where `key`='last_orders_export') and pa.isgroup = 0 
             ORDER BY 1";
        return $this->queryRow($sql);
    }

    private function GetOrders()
    {
        $from = $this->request['dtfrom'];
        if (!isset($this->request['dtfrom']) || empty($this->request['dtfrom'])) {
            $from = "";
        } else {
            $from = " AND DATE(o.date_modified) >= DATE(DATE_FORMAT('" . $_REQUEST['dtfrom'] . "','%Y-%m-%d %H:%i:%S')) ";
        }
        // Проставляем статусы заказов
        // Поиск удаленных заказов
        $this->removeOrderDeleteOrder();
        //Поиск измененных заказов
        $this->findChangeOrder();
        //Вставка новых заказов
        $this->putListOrder();
        //Получение списка заказов
        $list = $this->getlistOrder();
        if ($list === false) {
            throw new Exception('Заказы не найдены');
        } else {
            $this->query("update paloma_config set `value`=now() where `key`='last_orders_export'");
            return json_encode($list);
        }
    }

    private function findData($id, $key)
    {
        foreach ($this->syncFull as $item) {
            if ($item[$key] == $id) {
                return $item;
            }
        }
        return null;
    }

    private function buildTree($data, $id = 0, $level = 0)
    {
        $result = null;
        foreach ($data as $item) {
            if ($item['parentid'] == $id && $item['parentid'] != $item['id']) {
                $children = $this->buildTree($data, $item['id'], ($level + 1));
                $item['level'] = $level;
                if (in_array($item['id'], $this->sync)) {
                    $item['action'] = 1;
                    $id_ = $this->findData($item['id'], 'id_paloma');
                    $perent = $this->findData($item['parentid'], 'id_paloma');
                    $item['old_data_paloma_item'] = (is_null($perent)) ? NULL : $perent;
                    if (is_null($id_['id_opencard'])) {
                        $item['action'] = 2;
                    } else {
                        $item['opencart_id'] = $id_['id_opencard'];
                    }
                } else {
                    $item['action'] = 2;
                }
                $result[$item['id']] = ['item' => $item, 'children' => $children];
            }
        }
        return $result;
    }

    private function product($products)
    {
        $this
            ->db
            ->begin_transaction();
        if (is_array($products) || is_object($products)) {
            foreach ($products as $key => $value) {
                $value['img_opencart'] = $this->loadimage($value['img']);
                if (!in_array($value['id'], $this->sync)) {
                    $this->dataJson['id_opencard'] = $this->addProduct($value);
                } else {
                    $value['id_opencard'] = array_search($value['id'], $this->sync);
                    $this->updateProduct($value);
                }
            }
        }
        if (
            count($this
                ->db
                ->error_list) > 0
        ) {
            error_log(json_encode($this
                ->db
                ->error_list));
            file_put_contents('log_' . date("j.n.Y") . '.log', json_encode($this
                ->db
                ->error_list), FILE_APPEND);
            $this
                ->db
                ->rollback();
        }

        $this
            ->db
            ->commit();

    }

    private function actionCategoryAdd($data)
    {
        $req_dump = print_r($data, true);
        $fp = fopen('request.log', 'a');
        fwrite($fp, $req_dump);
        fclose($fp);
        if (is_array($data) || is_object($data)) {
            foreach ($data as $item) {
                $id_opencard = NULL;
                if ($item['item']['action'] == 2) {
                    $id_opencard = $this->addCategory($item['item']);
                }
                if (!is_null($item['children'])) {
                    foreach ($item['children'] as &$child) {
                        $child['item']['id_opencart_parent'] = $id_opencard;
                    }
                    $this->actionCategoryAdd($item['children']);
                }
            }
        }
        return null;
    }

    private function actionCategoryUpdate($data)
    {
        if (is_array($data) || is_object($data)) {
            foreach ($data as $item) {
                $id_opencard = NULL;
                if ($item['item']['action'] == 1) {
                    $id_opencard = $this->updateCategory($item['item']);
                }
                if (!is_null($item['children'])) {
                    foreach ($item['children'] as &$child) {
                        $child['item']['id_opencart_parent'] = $id_opencard;
                    }
                    $this->actionCategoryUpdate($item['children']);
                }
            }
        }
        return null;
    }

    private function category($categorys)
    {
        $categorys = $this->buildTree($categorys);
        $this->actionCategoryAdd($categorys);
        $this->actionCategoryUpdate($categorys);

    }

    private function syncProdCategory()
    {
        $products = [];
        $categorys = [];
        foreach ($this->dataJson as $key => $value) {
            $value['img_opencart'] = $this->loadimage($value['img']);
            if ($value['isgroup'] == 1) {
                $categorys[] = $value;
            } else {
                $products[] = $value;
            }
        }
        $this->category($categorys);
        $this->product($products);
    }

    private function removeEmptyItemSyncTable()
    {
        $result = $this->queryRow("SELECT id,id_paloma,IF(isgroup = 0,oc_product.product_id,oc_category.category_id) as open_id,isgroup   FROM paloma_api 
          LEFT JOIN oc_product ON  oc_product.product_id = id_opencard 
          LEFT JOIN oc_category ON oc_category.category_id= id_opencard 
          WHERE   ISNULL(oc_product.product_id) OR ISNULL(oc_category.category_id) HAVING ISNULL(open_id) ");
        $ids = [];
        foreach ($result as $item) {
            $ids[] = $item['id'];
        }
        if (count($ids) > 0) {
            $this->query("DELETE FROM paloma_api WHERE id IN(" . implode(',', $ids) . ")");
        }
    }
    private function showHide($item)
    {
        $status = 1;
        if ($item['mark_deleted'] == 1) {
            $status = 0;
            return $status;
        } else {
            if ($item['i_useInMenu'] == 0) {
                $status = 0;
                return $status;
            }
        }
        return $status;
    }

    private function addCategory($item)
    {
        $status = $this->showHide($item);
        $opencart_id = NULL;
        $$item['name'] = $this
            ->db
            ->real_escape_string($item['name']);
        $item['description'] = $this
            ->db
            ->real_escape_string($item['description']);
        $date = Date('Y-m-d');
        if ($item['parentid'] == 0) {
            $this->query("INSERT INTO oc_category (parent_id,status,date_added,date_modified,`column`,top)
              VALUES ('0',{$status},'$date','$date','1','1')", true);
            $opencart_id = mysqli_insert_id($this->db);
        } else {
            if (!isset($item['id_opencart_parent'])) {
                $id_opencart = $this->queryRow("SELECT id_opencard FROM paloma_api WHERE id_paloma='{$item['parentid']}'");
                $item['id_opencart_parent'] = $id_opencart[0]['id_opencart'];
            }
            $this->query("INSERT INTO oc_category (parent_id,status,date_added,date_modified,`column`,top)
              VALUES ('{$item['id_opencart_parent']}',{$status},'$date','$date','1','1')", true);
            $opencart_id = mysqli_insert_id($this->db);
        }
        $this->query("INSERT INTO paloma_api (id_paloma,id_opencard,isgroup,parentid) 
              VALUES ('{$item['id']}','{$opencart_id}','1','{$item['parentid']}')", true);

        $this->query("INSERT INTO oc_category_to_store (category_id,store_id) 
              VALUES ('{$opencart_id}', '0')", true);

        if ($item['parentid'] == 0) {
            $this->query("INSERT INTO oc_category_path (category_id,path_id,level) VALUES ('{$opencart_id}','{$opencart_id}','{$item['level']}')", true);
        } else {
            $this->query("INSERT INTO oc_category_path (category_id,path_id,level) VALUES ('{$opencart_id}','{$item['id_opencart_parent']}','{$item['level']}')", true);
        }
        $this->query("INSERT INTO oc_category_to_layout (category_id,store_id,layout_id) VALUES ('{$opencart_id}', '1', '1')", true);
        $this->query("INSERT INTO oc_category_description (category_id,language_id,name,meta_title,meta_description,description,meta_keyword,meta_h1) 
VALUES 
('{$opencart_id}','1','{$item['name']}','{$item['name']}','{$item['name']}','{$item['name']}','{$item['name']}','{$item['name']}')", true);
        return $opencart_id;
    }
    private function updateCategory($item)
    {
        $status = $this->showHide($item);
        $item['name'] = $this
            ->db
            ->real_escape_string($item['name']);
        $item['description'] = $this
            ->db
            ->real_escape_string($item['description']);
        $opencart_id = NULL;
        $date = Date('Y-m-d');
        if ($item['opencart_id']) {
            if (!is_null($item['old_data_paloma_item']['parentid']) && $item['parentid'] != $item['old_data_paloma_item']['parentid']) {
                $this->query("UPDATE paloma_api SET parentid='{$item['parentid']}' WHERE id_paloma={$item['id']}");
                $newParent = $this->queryRow("SELECT * FROM paloma_api WHERE id_paloma='{$item['parentid']}'");
                $this->query("UPDATE oc_category_path SET path_id ='{$newParent[0]['id_opencart']}',level ='{$item['level']}'
                    WHERE path_id = '{$item['id_opencart_parent']}' AND  category_id ='{$item['opencart_id']}' ");
                $this->query("UPDATE oc_category SET parent_id='{$newParent[0]['id_opencard']}',date_modified='$date', 
                status={$status} WHERE category_id='{$item['opencart_id']}'");
                $this->query("UPDATE oc_category_description SET name='{$item['name']}', meta_title='{$item['name']}', meta_keyword='{$item['name']}' WHERE category_id='{$item['opencart_id']}'");
            } else {
                $this->query("UPDATE oc_category SET date_modified='$date', 
                status={$status} WHERE category_id='{$item['opencart_id']}'");
                $this->query("UPDATE oc_category_description SET name='{$item['name']}', meta_title='{$item['name']}', meta_keyword='{$item['name']}' WHERE category_id='{$item['opencart_id']}'");
            }
        }
        return $item['opencart_id'];
    }

    private function getIdPaloma($type = null)
    {
        $where = "";
        if (!is_null($type)) {
            $where = " WHERE  isgroup='{$type}' ";
        }
        $list = $this->queryRow("SELECT id_paloma FROM paloma_api {$where}  ");
        $listNew = [];
        foreach ($list as $item) {
            $listNew[] = $item['id_paloma'];
        }
        return $listNew;
    }
    private function getIdPalomafullData($type = null)
    {
        $where = "";
        if (!is_null($type)) {
            $where = " WHERE  isgroup='{$type}' ";
        }
        $list = $this->queryRow("SELECT * FROM paloma_api {$where}  ");
        return $list;
    }

    private function updateProduct($item)
    {
        $date = Date('Y-m-d');
        $this->query("UPDATE paloma_api SET parentid='{$item['parentid']}' WHERE id_paloma='{$item['id']}'");
        $id_opencart = $this->queryRow("SELECT id_opencard FROM paloma_api WHERE id_paloma='{$item['id']}'");
        $id_opencart_category = $this->queryRow("SELECT id_opencard FROM paloma_api WHERE id_paloma='{$item['parentid']}'");
        $id_opencart = $id_opencart[0]['id_opencard'];
        $id_opencart_category = $id_opencart_category[0]['id_opencard'];
        $status = $this->showHide($item);

        $item['name'] = $this
            ->db
            ->real_escape_string($item['name']);
        $item['description'] = $this
            ->db
            ->real_escape_string($item['description']);
        $this->query("UPDATE oc_product_to_category SET category_id='{$id_opencart_category}' WHERE product_id='{$id_opencart}'");
        $this->query("UPDATE oc_product SET model='{$item['name']}', price='{$item['price']}',status={$status},
                      date_modified='$date', image='{$item['img_opencart']}', quantity='{$item['remains']}' WHERE product_id='{$id_opencart}'");
        $this->query("UPDATE oc_product_description SET name='{$item['name']}', description='{$item['description']}', meta_title='{$item['name']}' WHERE product_id='{$id_opencart}'");
    }
    private function addProduct($item)
    {
        $date = Date('Y-m-d');
        $item['name'] = $this
            ->db
            ->real_escape_string($item['name']);
        $item['description'] = $this
            ->db
            ->real_escape_string($item['description']);
        $status = $this->showHide($item);
        //Добавление в таблицу oc_product
        $insert = "INSERT INTO oc_product (model,price,status,image,quantity,date_added,date_modified,tax_class_id,manufacturer_id,stock_status_id,location,mpn,isbn,jan,ean,upc,sku) 
                 VALUES ('{$item['name']}','{$item['price']}',{$status},'{$item['img_opencart']}','{$item['remains']}','{$date}','{$date}', '1','1','1',' ',' ',' ',' ',' ',' ','{$item['id']}')";
        //file_put_contents('log_' . date("j.n.Y") . '.log', $insert . "\r\n", FILE_APPEND);
        $res = $this->query($insert);
        if ($res === false) {
            throw new Exception('Ошибка ' . $insert);
        }
        $idd = mysqli_insert_id($this->db);
        $insert = "INSERT INTO paloma_api (id_paloma,id_opencard,isgroup,parentid) 
                  VALUES ('{$item['id']}','{$idd}','0','{$item['parentid']}')";
        //file_put_contents('log_' . date("j.n.Y") . '.log', $insert . "\r\n", FILE_APPEND);
        $this->query($insert);
        $insert = "INSERT INTO oc_product_to_store (product_id,store_id)
                  VALUES ('$idd','0')";
        //file_put_contents('log_' . date("j.n.Y") . '.log', $insert . "\r\n", FILE_APPEND);
        $this->query($insert);
        $insert = "INSERT INTO oc_product_to_layout (product_id,store_id,layout_id)
                  VALUES ('$idd','0','0')";
        //file_put_contents('log_' . date("j.n.Y") . '.log', $insert . "\r\n", FILE_APPEND);
        $this->query($insert);

        if (is_null($item['description']) || empty($item['description'])) {
            $item['description'] = " ";
        }
        $item['description'] = htmlentities(addslashes($item['description']));
        $insert1 = "INSERT INTO oc_product_description (product_id,language_id,name,description,meta_title,tag,meta_description,meta_keyword,meta_h1) 
                  VALUES ('$idd','1','{$item['name']}','{$item['description']}','{$item['name']}','$idd','{$item['description']}','{$item['name']}','{$item['name']}')";
        //file_put_contents('log_' . date("j.n.Y") . '.log', $insert1 . "\r\n", FILE_APPEND);
        $this->query($insert1);
        $id_opencart = $this->queryRow("SELECT * FROM paloma_api WHERE id_paloma='{$item['parentid']}'");
        if (isset($id_opencart[0]['id_opencard']) && !empty($id_opencart[0]['id_opencard'])) {
            $insert = "INSERT INTO oc_product_to_category (product_id,category_id) 
                  VALUES ('$idd',{$id_opencart[0]['id_opencard']})";
            //file_put_contents('log_' . date("j.n.Y") . '.log', $insert . "\r\n", FILE_APPEND);
            $this->query($insert);
        }
        return $idd;
    }
    private function removeOrderDeleteOrder()
    {
        $sql = "update paloma_orders po set po.action='delete', po.import_date=now() 
             where po.order_id not in (select oo.order_id from oc_order oo)";
        $this->query($sql);
    }
    private function findChangeOrder()
    {
        $sql = "update paloma_orders po set po.action='update',  po.import_date=now() 
             where po.order_id in (select oo.order_id from oc_order oo where oo.date_modified>=po.import_date)
             and po.action<>'delete' ";
        $this->query($sql);
    }
    private function putListOrder()
    {
        $sql = "insert paloma_orders (order_id,import_date,action)
        (select order_id,now(),'insert' from oc_order oo 
                        where oo.order_id not in (select po.order_id from paloma_orders po))";
        $this->query($sql);
    }
    private function loadimage($img)
    {
        if ($img != '') {
            $fn = explode("/", $img);
            $filename = $fn[count($fn) - 1];
            $imag = 'catalog/' . $filename;
            $local = 'image/' . $imag;
            //file_put_contents($local, file_get_contents($img));
        } else {
            $imag = "";
        }
        return $imag;
    }

}
try {
    $api = new PalomaApi($_REQUEST);
    $api->Action();
    $log = $api->getLog();
    if (count($log) > 0) {
        echo json_encode($log);
    }
} catch (Throwable $e) {
    var_dump($e->getMessage());
}
?>