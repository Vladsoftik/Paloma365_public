var socket = new Array(sock_cnt);
var heartbeats = new Array(sock_cnt); 
var audio = new Audio('beep_2.mp3');

// Хранилище состояний заказов: { "номер_заказа": статус }
const orderStates = new Map(); 

// Проверка и разблокировка звука
function initAudio() {
    audio.play().then(() => {
        document.getElementById('sound-notification').style.display = 'none';
        console.log("Звук уже разрешен");
    }).catch(() => {
        document.getElementById('sound-notification').style.display = 'block';
    });
}

document.addEventListener('click', function () {
    audio.play().then(() => {
        document.getElementById('sound-notification').style.display = 'none';
    }).catch(error => console.log("Ошибка аудио:", error));
}, { once: true });

initAudio();

function getFontSize(text) {
    const len = text.length;
    if (len <= 3) return '5rem';    
    if (len <= 6) return '3.5rem';  
    if (len <= 15) return '2.2rem'; 
    if (len <= 30) return '1.8rem'; 
    if (len <= 50) return '1.5rem'; 
    return '1.2rem';               
}

function createOrderCard(text, type) {
    const card = document.createElement('div');
    card.className = 'order-card ' + type;
    card.style.fontSize = getFontSize(text);
    card.textContent = text;
    return card;
}

function updateContainer(containerId, orderText, type, shouldSound) {
    const container = document.getElementById(containerId);
    const existingCards = Array.from(container.querySelectorAll('.order-card'));
    const isDuplicate = existingCards.some(card => card.textContent === orderText);
    
    if (!isDuplicate) {
        container.appendChild(createOrderCard(orderText, type));
        container.scrollTop = container.scrollHeight;
        if (shouldSound) {
            playSound();
        }
    }
}

function removeFromContainer(containerId, orderText) {
    const container = document.getElementById(containerId);
    const cards = container.querySelectorAll('.order-card');
    cards.forEach(card => {
        if (card.textContent === orderText) {
            card.remove();
        }
    });
}

function socket_refresh(i) {
    if (socket[i]) {
        socket[i].onopen = null;
        socket[i].onmessage = null;
        socket[i].onclose = null;
        socket[i].onerror = null;
        socket[i].close();
    }

    socket[i] = new WebSocket("ws://" + sock_adr[i] + "/", ["chat"]);
    
    socket[i].onopen = function() {
        document.getElementById('info').innerHTML = sock_adr[i] + ' - Соединен';
        socket[i].send('123');
        
        if (heartbeats[i]) clearInterval(heartbeats[i]);
        heartbeats[i] = setInterval(() => {
            if (socket[i].readyState === WebSocket.OPEN) {
                socket[i].send('123'); 
            }
        }, 30000); 
    };

    socket[i].onmessage = function(event) {
        let server_message = event.data;

        if (server_message === 'clear') {
            document.getElementById('new').innerHTML = '';
            document.getElementById('ready').innerHTML = '';
            // Мы НЕ очищаем orderStates, чтобы помнить старые заказы
            return;
        }

        try {
            const data = JSON.parse(server_message);
            const orderNum = data.mess.toString().trim();
            const status = parseInt(data.status);
            
            // Проверяем, изменился ли статус заказа
            const lastStatus = orderStates.get(orderNum);
            let needsSound = false;

            if (lastStatus === undefined || lastStatus !== status) {
                needsSound = true;
                orderStates.set(orderNum, status);
            }

            if (status === 0 || status === 1) {
                updateContainer('new', orderNum, 'new', needsSound);
            } 
            else if (status === 2) {
                removeFromContainer('new', orderNum);
                updateContainer('ready', orderNum, 'ready', needsSound);
            }
        } catch (e) {
            console.log("Пропуск не-JSON данных");
        }
    };

    socket[i].onclose = function() {
        document.getElementById('info').innerHTML = sock_adr[i] + ' - Отключен';
        setTimeout(() => socket_refresh(i), 5000);
    };

    socket[i].onerror = function(err) {
        console.error('Socket error:', err);
    };
}

for (var i = 0; i < sock_cnt; i++) {
    socket_refresh(i);
}

function playSound() {
    setTimeout(() => {
        audio.play().catch(error => console.log("Ошибка звука:", error));
    }, 50);
}
