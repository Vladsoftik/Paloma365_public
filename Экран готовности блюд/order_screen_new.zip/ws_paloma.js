var socket = new Array(sock_cnt);
console.log('sock_cnt='+sock_cnt);
function socket_refresh(i){       
            socket[i] = new WebSocket("ws://"+sock_adr[i]+"/",["chat"]);
            socket[i].onopen = function() {
                        document.getElementById('info').innerHTML=sock_adr[i]+' - Сокет открыт';
                        socket[i].send('123');
                        console.log('output message');
            };
            socket[i].onmessage=function(event) {
                        var server_message = event.data;
                        console.log('message - '+server_message);
                        if (server_message=='clear'){
                                    document.getElementById('new').innerHTML='';
                                    document.getElementById('ready').innerHTML='';
                                    return;
                        }
                        var mes_array=server_message.split('-');
                        var data = JSON.parse(server_message);
                        s2=pad(data.mess,3)+'<br>';
                        if (data.status==0){
                                    s1=document.getElementById('new').innerHTML;
                                    document.getElementById('new').innerHTML=add_text(s1,s2);
                                    return;
                        }
                        if (data.status==1){
                                    s1=document.getElementById('new').innerHTML;
                                    document.getElementById('new').innerHTML=add_text(s1,s2);   
                        }
                        if (data.status==2){
                                    s1=document.getElementById('ready').innerHTML;
                                    document.getElementById('ready').innerHTML=add_text(s1,s2);
                                    return;
                        }
            };                                 
            socket[i].onclose = function(event) {
                        if (event.wasClean) {
                                    document.getElementById('info').innerHTML='Соединение закрыто чисто';
                        } else {
                                    document.getElementById('info').innerHTML=sock_adr[i]+' - Сокет закрыт';
                                    setInterval(pause(),5000);					
                        } 
            };
            socket[i].onerror = function(error) {
                console.log('error: '+ error);
            };
}

for (var i=0;i<sock_cnt;i++){
            console.log('sock_refresh='+i);
            socket_refresh(i);
}
                       
function pause(){
            for (var ind=0;ind<sock_cnt;ind++){
                        if (socket[ind].readyState !== WebSocket.OPEN){
                                     setInterval(socket_refresh(ind),5000);
                        }
            }
}

function add_text(s1,s2){
            if (s1!=''){
                        if(s1.indexOf(s1) + 1) {
                                    return s1+s2;
                        }else{
                                    return s1;
                        }
            }else return s2;
}

function pad(str, max){
            str = str.toString();
            return str.length < max ? pad("0" + str, max) : str;
}