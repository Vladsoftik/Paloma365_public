Файл functions-api.php нужно разместить в корне сайта 
чтобы он был доступен по пути 
Адрес сайта / functions-api.php 
и возвращал Status is OK